import Lightbox from './react-image-lightbox';

export default Lightbox;
